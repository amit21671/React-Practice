import axios from 'axios';
import { useEffect, useState } from 'react';

import './App.css';
const App = () => {
  const [users, setUsers] = useState([]);
  const [clc, setClc] = useState(false);

  const handleClick = () => {
    setClc(true)
  }

  useEffect(() => {
    const getUser = async () => {
      try {
        const response = await axios.get('https://jsonplaceholder.typicode.com/users');
        //console.log(response.data);
        setUsers(response.data);
      } catch (error) {
        console.error(error);
      }
    }
    getUser();
  }, []);
  //console.log("before return ", users)
  return (
    <>
 

      <h1 className='box1'>Grid of Cards</h1>
      {clc ? <>{
        users.map((user, i) => {
          return (
            <div className='box' key={user.id}>
                  <div className='circle'>
                      {user.name.charAt(0).toUpperCase()} <br />
                    </div>
                    <div className='username'>
                      {user.name}
                      </div>
            
            </div>
          )
        })
      } </> : <>
        {
          users.map((user, i) => {
            {
              if (i < 3) {
                return (
                  <div className='box' key={user.id}>
                    <div className='circle'>
                      
                      {user.name.charAt(0).toUpperCase()} <br />
                    </div>
                    <div className='username'>
                      {user.name}
                      </div>
                  </div>
                )
              }
            }
          })
        }
      </>
      }
      <br />
      {clc ? <></> : <> <input className='box2' type="button" value="Show more" onClick={handleClick}/> </>}


    </>
  );
}
export default App;