import React, { useState } from 'react';
import axios from 'axios';
import './styles.css';
function App() {
    const [users, setUsers] = useState([]);
    const [error, setError] = useState();
    const [input, setInput] = useState("");
    const [check ,setCheck] = useState(false)
    const handleChange = (e) => {
      setInput(e.target.value)
    }
    const handleClick = ()=>{
                          const getUser = async () => {
                              try {
                                  const response = await axios.get('https://api.github.com/users/'+input+'/repos');
                                  setUsers(response.data);
                              } catch (error) {
                                  setError("Not Found")
                              }
                          }
                          getUser();
    }
    const handleCheck = ()=>{
      setCheck(!check);
    }
  return (
    <div className="App">
      <div className="input">
        <label htmlFor="username">Github username: </label>
        <input id="username" type="text" value ={input} onChange={handleChange} />
        <label htmlFor="fork">Include forks: </label>
        <input id="fork" type="checkbox"  onClick={handleCheck} />
        <input className='button' type='button' value='submit' onClick={handleClick} />
      </div>
      <section>
                <header>
                  <div className="col">Name</div>
                  <div className="col">Language</div>
                  <div className="col">Description</div>
                  <div className="col">Size</div>
                  <div className="col">Forks</div>
                </header>
                {!check?
                <>
                {
                    users.filter(user=>user.fork===true).map((user,i)=>{return(
                      <div key={i}>
                          <div className="col">{user.name}</div>
                          <div className="col">{user.language}</div>
                          <div className="col">{user.description}</div>
                          <div className="col">{user.size}</div>
                          <div className="col">{user.forks}</div>
                      </div>
                    )})
                }
                </>
                :
                <>
                {
                    users.map((user,i)=>{return(
                      <div key={i}>
                          <div className="col">{user.name}</div>
                          <div className="col">{user.language}</div>
                          <div className="col">{user.description}</div>
                          <div className="col">{user.size}</div>
                          <div className="col">{user.forks}</div>
                      </div>

                    )})
                }
                </>
                }

      </section>
      <div className="error">{error}</div>
    </div>
  );
}

export default App;
